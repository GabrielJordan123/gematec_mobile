import apiClient from "../Context/ApiClient";

interface FetchServiceOrdersParams {
    host: string;
    token: string;
    filters: {
        search?: string;
        equipment_type?: string;
        brand?: string;
        status?: string;
    };
    page: number;
}

class ServiceOrderService {
    static async fetchServiceOrders({ host, token, filters, page }: FetchServiceOrdersParams) {
        try {
            const url = `${host}/service_orders?page=${page}&per_page=10`;

            const params = {
                search: filters.search || '',
                equipment_type: filters.equipment_type || '',
                brand: filters.brand || '',
                status: filters.status || 'open',
            };

            const response = await apiClient.get(url, {
                headers: { Authorization: `Bearer ${token}` },
                params,
            });

            return response.data;
        } catch (error) {
            console.error('Erro ao buscar ordens de serviço:', error);
            throw error;
        }
    }

    static async fetchServiceOrderDetails(token: string, serviceOrderId: number, host: string) {
        try {
            const response = await apiClient.get(`${host}/service_orders/${serviceOrderId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar detalhes da ordem de serviço:', error);
            throw error;
        }
    }

    static async fetchAnswers(token: string, serviceOrderId: number, host: string) {
        try {
            const response = await apiClient.get(`${host}/service_orders/${serviceOrderId}/answers`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar respostas:', error);
            throw error;
        }
    }

    static async uploadImages(token: string, serviceOrderId: number, host: string, formData: FormData) {
        try {
            const response = await apiClient.post(`${host}/service_orders/${serviceOrderId}/images`, formData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'multipart/form-data',
                },
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao fazer upload de imagens:', error);
            throw error;
        }
    }

    static async fetchImages(token: string, serviceOrderId: number, host: string) {
        try {
            const response = await apiClient.get(`${host}/service_orders/${serviceOrderId}/images`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar imagens:', error);
            throw error;
        }
    }
}

export default ServiceOrderService;