import axios from "axios";
import apiClient from "../Context/ApiClient";

export default class TechnicalAssistanceService {
    private host: string;

    constructor(host: string) {
        this.host = host;
    }

    async fetchTechnicalAssistance(token: string, p0: { page: number; per_page: number; }, params?: {
        token: string;
        page?: number;
        per_page?: number;
        search?: string;
        equipment_type?: string;
        brand?: string;
        status?: string;
    }) {
        const endpoint = `${this.host}/api/technical_assistances`;
        console.log('Endpoint:', endpoint);

        try {
            const response = await apiClient.get(endpoint, {
                headers: {
                    Authorization: `Bearer ${token}`
                },
                params: {
                    page: params?.page,
                    per_page: params?.per_page,
                    search: params?.search,
                    equipment_type: params?.equipment_type,
                    brand: params?.brand,
                    status: params?.status
                }
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar assistências técnicas:', error);
            if (axios.isAxiosError(error)) {
                console.error('Detalhes do erro:', {
                    status: error.response?.status,
                    data: error.response?.data,
                    config: error.config
                });
            }
            throw new Error('Erro ao carregar assistências técnicas. Tente novamente mais tarde.');
        }
    }

    async fetchClients(token: string, search: string) {
        const endpoint = `${this.host}/api/clients`;
        try {
            const response = await apiClient.get(endpoint, {
                headers: { Authorization: `Bearer ${token}` },
                params: { search }
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar clientes:', error);
            throw new Error('Erro ao carregar clientes.');
        }
    }
    async fetchTechnicalAssistanceDetails(token: string, technicalAssistanceId: number) {
        const endpoint = `${this.host}/technical_assistances/${technicalAssistanceId}`;
        try {
            const response = await apiClient.get(endpoint, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar detalhes da assistência técnica:', error);
            throw error;
        }
    }
    async fetchSectors(token: string, clientId: number, search: string) {
        const endpoint = `${this.host}/api/clients/${clientId}/sectors`;
        try {
            const response = await apiClient.get(endpoint, {
                headers: { Authorization: `Bearer ${token}` },
                params: { search }
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar setores:', error);
            throw new Error('Erro ao carregar setores.');
        }
    }

    async fetchEquipments(token: string, sectorId: number, search: string) {
        const endpoint = `${this.host}/api/sectors/${sectorId}/equipments`;
        try {
            const response = await apiClient.get(endpoint, {
                headers: { Authorization: `Bearer ${token}` },
                params: { search }
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar equipamentos:', error);
            throw new Error('Erro ao carregar equipamentos.');
        }
    }
    // TechnicalAssistanceService.ts
    async fetchAnswers(token: string, technicalAssistanceId: number) {
        const endpoint = `${this.host}/api/technical_assistances/${technicalAssistanceId}/answers`;
        try {
            const response = await apiClient.get(endpoint, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar respostas:', error);
            throw error;
        }
    }
    async createTechnicalAssistance(token: string, data: { equipment_id: number }) {
        const endpoint = `${this.host}/api/technical_assistances`;
        try {
            const response = await apiClient.post(endpoint, data, {
                headers: { Authorization: `Bearer ${token}` }
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao criar assistência técnica:', error);
            throw new Error('Erro ao criar assistência técnica.');
        }
    }
}