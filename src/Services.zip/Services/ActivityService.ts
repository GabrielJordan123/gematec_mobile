import axios from "axios";

export default class ActivityService {
    private host: string;

    constructor(host: string) {
        this.host = host;
    }

    async fetchActivities(
        equipmentId: number,
        params: {
            page?: number;
            per_page?: number;
            activity_type?: string;
            token: string;
        }
    ) {
        try {
            const response = await axios.get(`${this.host}/api/equipments/${equipmentId}/activities`, {
                headers: {
                    Authorization: `Bearer ${params.token}`,
                },
                params: {
                    page: params?.page,
                    per_page: params?.per_page,
                    activity_type: params?.activity_type
                }
            });
            return response.data;
        } catch (error) {
            console.error('Erro ao buscar atividades do equipamento:', error);
            throw error;
        }
    }
}