import axios from 'axios';
import { Equipment } from '../Models/Equipament';
import apiClient from "../Context/ApiClient";

export default class EquipmentService {
  static async fetchEquipments(
    host: string,
    token: string,
    filters: any
  ): Promise<{ results: Equipment[]; count: number }> {
    try {
      const params = new URLSearchParams(filters).toString();
      const url = `${host}/api/equipments?${params}`;
      const response = await apiClient.get(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      return response.data; // Deve retornar { results, count }
    } catch (error: any) {
      console.error("[EquipmentService] Erro ao buscar equipamentos:", error);
      throw new Error("[EquipmentService] Erro ao buscar equipamentos.");
    }
  }
  static async fetchEquipmentDetails(equipmentId: string, host: string, accessToken: string) {
    try {
      const response = await apiClient.get(`${host}/api/equipments/${equipmentId}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      return response.data;
    } catch (error: any) {
      console.error("[EquipmentService] Erro ao buscar detalhes do equipamento:", error.message);
      throw new Error(error.response?.data?.message || "Falha ao buscar detalhes do equipamento.");
    }
  }
  static async createEquipment(host: string, token: string, data: any) {
    try {
      console.log("[EquipmentService] Criando equipamento...", data);

      const response = await apiClient.post(`${host}/api/equipments`, data, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      console.log("[EquipmentService] Equipamento criado:", response.data);
      return response.data;
    } catch (error: any) {
      console.error("[EquipmentService] Erro ao criar equipamento:", error);
      throw new Error(error.response?.data?.message || "Falha na criação.");
    }
  }
  static async updateEquipment(
    host: string,
    token: string,
    equipmentId: string,
    data: any
  ): Promise<any> {
    try {
      console.log("[EquipmentService] Atualizando equipamento...");
      console.log("[EquipmentService] Host:", host);
      console.log("[EquipmentService] ID do Equipamento:", equipmentId);
      console.log("[EquipmentService] Dados para atualização:", data);

      const response = await apiClient.put(`${host}/api/equipments/${equipmentId}`, data, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      console.log("[EquipmentService] Equipamento atualizado com sucesso:", response.data);
      return response.data;
    } catch (error: any) {
      console.error("[EquipmentService] Erro ao atualizar equipamento:", error);

      if (error.response) {
        console.error("[EquipmentService] Erro no servidor:");
        console.error("Status:", error.response.status);
        console.error("Dados:", error.response.data);

        // Tratamento de códigos de erro específicos
        if (error.response.status === 404) {
          throw new Error("Equipamento não encontrado.");
        } else if (error.response.status === 401) {
          throw new Error("Token de acesso inválido ou expirado.");
        } else {
          throw new Error("Erro inesperado no servidor.");
        }
      } else if (error.request) {
        console.error("[EquipmentService] Nenhuma resposta recebida do servidor:", error.request);
        throw new Error("Falha na conexão com o servidor. Verifique sua rede.");
      } else {
        console.error("[EquipmentService] Erro ao configurar requisição:", error.message);
        throw new Error("Erro ao configurar a requisição. Verifique os parâmetros.");
      }
    }
  }

  static async removeEquipment(host: string, token: string, equipmentId: number): Promise<void> {
    try {
      console.log(`[EquipmentService] Removendo equipamento com ID: ${equipmentId}`);
      const response = await apiClient.delete(`${host}/api/equipments/${equipmentId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      console.log("[EquipmentService] Equipamento removido com sucesso:", response.data);
    } catch (error: any) {
      console.error("[EquipmentService] Erro ao remover equipamento:", error);

      if (error.response) {
        if (error.response.status === 404) {
          throw new Error("Equipamento não encontrado.");
        } else if (error.response.status === 401) {
          throw new Error("Token de acesso inválido ou expirado.");
        }
      }

      throw new Error(error.message || "Erro ao remover o equipamento.");
    }
  }

}
