import axios from 'axios';
import PersonalData from '../Models/PersonalData';
import apiClient from "../Context/ApiClient"
const BASE_URL = 'http://128.199.5.151';

export default class PersonalDataService {
  static async getPersonalData(accessToken: string): Promise<PersonalData> {
    try {
      const response = await apiClient.get(`${BASE_URL}/api/me`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return new PersonalData(response.data);
    } catch (error: any) {
      throw new Error('Erro ao buscar dados pessoais. Tente novamente mais tarde.');
    }
  }
  static async updatePersonalData(accessToken: string, host: string, updatedData: { name?: string; birthdate?: string; rh_factor?: string }) {
    try {
      const endpoint = `${host}/api/me`;
      console.log('Atualizando dados pessoais no endpoint:', endpoint);
      console.log('Dados enviados:', updatedData);

      const response = await axios.patch(endpoint, updatedData, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      console.log('Resposta da atualização:', response.data);
      return response.data;
    } catch (error: any) {
      console.error('Erro durante a atualização dos dados pessoais:', error);
      if (error.response) {
        console.error('Detalhes do erro:', {
          status: error.response.status,
          data: error.response.data,
        });
        throw new Error(`Erro: ${error.response.data.detail || 'Falha ao atualizar os dados.'}`);
      }
      throw new Error('Erro ao conectar ao servidor.');
    }
  }
}
